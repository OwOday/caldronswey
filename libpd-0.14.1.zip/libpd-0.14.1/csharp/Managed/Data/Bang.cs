using System;

namespace LibPDBinding.Managed.Data
{
	/// <summary>
	/// Pd bang message.
	/// </summary>
	public class Bang
	{
	}
}
