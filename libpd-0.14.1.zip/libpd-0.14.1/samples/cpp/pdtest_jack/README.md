# C++ JACK Example.

This is a basic C++ sample application that uses the JACK library for audio output.  It has been tested on Linux and macOS. See the JACK documentation for details.

## License

Copyright (c) 2014 Rafael Vega <rvega@elsoftwarehamuerto.org>
 
BSD Simplified License.
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "LICENSE.txt," in this distribution.

See https://github.com/libpd/libpd for documentation
