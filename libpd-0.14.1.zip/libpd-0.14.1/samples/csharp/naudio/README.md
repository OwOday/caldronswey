# C# NAudio example

This is a basic C# sample application that uses NAudio library for audio output.  It has been tested on Windows and Linux. See [the NAudio source for documentation](https://github.com/naudio/NAudio)

## License

Copyright (c) 2016 Thomas Mayer <thomas@residuum.org>
 
BSD Simplified License.
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "LICENSE.txt," in this distribution.

See https://github.com/libpd/libpd for documentation
